module StreamsEg {
}